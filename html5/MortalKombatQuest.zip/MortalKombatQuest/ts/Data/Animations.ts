class Animations { 
    //public static Akuma: string = 'Akuma.json';

    
    public static preloadList:Array<string> = [
        //Animations.Akuma,
    ];
}