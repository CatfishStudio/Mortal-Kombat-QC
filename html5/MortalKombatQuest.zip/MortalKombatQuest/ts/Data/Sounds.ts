class Sounds {
    //public static MenuMusic1: string = 'music1';


    public static preloadList:Array<string> = [
        //Sounds.MenuMusic1
    ];
}