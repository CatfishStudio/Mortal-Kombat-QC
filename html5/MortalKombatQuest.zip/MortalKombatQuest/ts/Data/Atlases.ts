class Atlases { 
    //public static Flash: string = 'Flash';
    
    public static preloadList:Array<string> = [
        //Atlases.Flash
    ];
}