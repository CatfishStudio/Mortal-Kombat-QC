class Images {
    public static PreloaderImage: string = 'preloader.jpg';

    //public static MenuImage: string = 'menu.png';

    public static preloadList:Array<string> = [
        //Images.MenuImage,
    ]; 
}