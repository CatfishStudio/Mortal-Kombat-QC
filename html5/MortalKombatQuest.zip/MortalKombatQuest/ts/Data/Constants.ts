class Constants {
    public static GAME_WIDTH            = 800;
    public static GAME_HEIGHT           = 600;

    public static TIMER_END             = "timer_end";
    public static GAME_OVER             = "game_over";
}