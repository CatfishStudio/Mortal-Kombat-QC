class Sheet {
    //public static ButtonStyle1: string = 'button_style_1_sheet.png';
   
    
    public static preloadList:Array<string> = [
        //Sheet.ButtonStyle1,
    ]; 
    
}