class Config {
    public static settingSound:boolean = true;
    public static settingMusic:boolean = true;
    public static settingTutorial:boolean = true;

    public static buildDev:boolean = false;
}